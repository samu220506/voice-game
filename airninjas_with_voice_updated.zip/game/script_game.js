document.addEventListener("DOMContentLoaded", async function () {
  const video = document.getElementById("webcam");
  const canvas = document.getElementById("gestureCanvas");
  const ctx = canvas.getContext("2d");
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  
  // Load hand tracking model
  const model = await handpose.load();
  navigator.mediaDevices.getUserMedia({ video: true }).then((stream) => {
      video.srcObject = stream;
  });
  
  function detectHands() {
      model.estimateHands(video).then((predictions) => {
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          if (predictions.length > 0) {
              const hand = predictions[0].landmarks;
              const wristX = hand[0][0];
              if (wristX < canvas.width / 3) moveLeft();
              else if (wristX > (canvas.width * 2) / 3) moveRight();
              
              const thumbTip = hand[4];
              const indexTip = hand[8];
              const distance = Math.hypot(thumbTip[0] - indexTip[0], thumbTip[1] - indexTip[1]);
              if (distance < 40) throwStar();
          }
          requestAnimationFrame(detectHands);
      });
  }
  detectHands();
  
  // Voice Command Recognition
  const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
  recognition.continuous = true;
  recognition.lang = "en-US";
  recognition.onresult = (event) => {
      const command = event.results[event.results.length - 1][0].transcript.toLowerCase();
      if (command.includes("move left")) moveLeft();
      if (command.includes("move right")) moveRight();
      if (command.includes("throw star")) throwStar();
  };
  recognition.start();
  
  // Functions to control the game
  function moveLeft() {
      window.dispatchEvent(new Event("moveLeft"));
  }
  function moveRight() {
      window.dispatchEvent(new Event("moveRight"));
  }
  function throwStar() {
      window.dispatchEvent(new Event("throwStar"));
  }
});