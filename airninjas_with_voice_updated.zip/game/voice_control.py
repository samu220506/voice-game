
import pyttsx3
import speech_recognition as sr
import keyboard  # Simulate key presses
import sys

engine = pyttsx3.init()
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)  # Female voice
engine.setProperty('rate', 150)  # Normal speed
engine.setProperty('volume', 1.0)

def speak(audio):
    engine.say(audio)
    engine.runAndWait()

def take_command():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening for command...")
        recognizer.pause_threshold = 0.5

        try:
            audio = recognizer.listen(source, timeout=5)
        except sr.WaitTimeoutError:
            speak("Listening timed out. Please try again.")
            return None

    try:
        print("Recognizing...")
        command = recognizer.recognize_google(audio, language="en-in")
        print(f"User said: {command}")
        return command.lower()
    except sr.UnknownValueError:
        speak("Sorry, I didn't catch that.")
    except sr.RequestError:
        speak("Speech service is unavailable.")
    return None

def process_command(command):
    if "left" in command:
        keyboard.press_and_release("left")
        speak("Moving left")
    elif "right" in command:
        keyboard.press_and_release("right")
        speak("Moving right")
    elif "up" in command or "jump" in command:
        keyboard.press_and_release("up")
        speak("Jumping")
    elif "down" in command:
        keyboard.press_and_release("down")
        speak("Moving down")
    elif "start" in command or "play" in command:
        keyboard.press_and_release("space")
        speak("Starting game")
    elif "pause" in command:
        keyboard.press_and_release("p")
        speak("Game paused")
    elif "quit" in command or "exit" in command:
        speak("Quitting the voice control")
        sys.exit()
    else:
        speak("Command not recognized. Please try again.")

def main():
    speak("Voice control activated. Say a command.")
    while True:
        command = take_command()
        if command:
            process_command(command)

if __name__ == "__main__":
    main()
