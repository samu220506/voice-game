<?php
session_start();
$conn = new mysqli("localhost", "root", "", "airninjas");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(["error" => "User not logged in"]);
    exit();
}

$user_id = $_SESSION['user_id'];
$score = $_POST['score'];

// Save score only if it's the best
$sql = "INSERT INTO leaderboard (user_id, score) VALUES (?, ?) 
        ON DUPLICATE KEY UPDATE score = GREATEST(score, VALUES(score))";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $user_id, $score);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    echo json_encode(["success" => "Score saved successfully"]);
} else {
    echo json_encode(["error" => "Failed to save score"]);
}

$stmt->close();
$conn->close();
?>
