import cv2
import mediapipe as mp
import keyboard
import time

# Mediapipe setup
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils

# Finger tips landmark indices
finger_tips = [4, 8, 12, 16, 20]  # Thumb, Index, Middle, Ring, Pinky

# Function to count raised fingers
def count_fingers(hand_landmarks):
    count = 0
    landmarks = hand_landmarks.landmark

    # Thumb
    if landmarks[finger_tips[0]].x < landmarks[finger_tips[0] - 1].x:
        count += 1
    # Other four fingers
    for tip in finger_tips[1:]:
        if landmarks[tip].y < landmarks[tip - 2].y:
            count += 1
    return count

# Mapping fingers to keypress
def map_gesture_to_key(finger_count):
    key_mapping = {
        1: 'up',
        2: 'down',
        3: 'left',
        4: 'right',
        5: 'space'
    }
    return key_mapping.get(finger_count, None)

# Initialize webcam
cap = cv2.VideoCapture(0)

with mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.7) as hands:
    prev_key = None
    last_pressed_time = 0

    while cap.isOpened():
        success, frame = cap.read()
        if not success:
            break

        # Flip and convert color
        frame = cv2.flip(frame, 1)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        # Process hand landmarks
        results = hands.process(rgb)

        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

                finger_count = count_fingers(hand_landmarks)
                key = map_gesture_to_key(finger_count)

                # Prevent rapid key spamming
                current_time = time.time()
                if key and (current_time - last_pressed_time > 1):
                    print(f"Fingers: {finger_count}, Pressing key: {key}")
                    keyboard.press(key)
                    time.sleep(0.2)
                    keyboard.release(key)
                    last_pressed_time = current_time

        # Show camera feed
        cv2.imshow("Hand Gesture Control", frame)

        if cv2.waitKey(1) & 0xFF == 27:  # ESC to exit
            break

cap.release()
cv2.destroyAllWindows()
