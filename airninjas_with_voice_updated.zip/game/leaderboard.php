<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "airninjas");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch top 10 players from leaderboard
$sql = "SELECT user.name, leaderboard.score 
        FROM leaderboard 
        JOIN user ON leaderboard.user_id = user.id 
        ORDER BY leaderboard.score DESC 
        LIMIT 10";
$result = $conn->query($sql);

$leaderboard = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $leaderboard[] = $row;
    }
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($leaderboard);
$conn->close();
?>
