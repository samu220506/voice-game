// Import Three.js
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ antialias: true });

renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
document.body.appendChild(renderer.domElement);

// Add Lighting
const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
scene.add(ambientLight);

const flickeringLight = new THREE.PointLight(0xff0000, 2, 10);
flickeringLight.position.set(0, 5, 0);
scene.add(flickeringLight);

function flickerLight() {
    flickeringLight.intensity = Math.random() * 2 + 0.5;
    setTimeout(flickerLight, Math.random() * 500 + 100);
}
flickerLight();

const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
directionalLight.position.set(5, 10, 5);
directionalLight.castShadow = true;
scene.add(directionalLight);

// Background Music
let musicPlaying = false;
function playBackgroundMusic() {
    if (!musicPlaying) {
        const audio = new Audio('https://www.fesliyanstudios.com/play-mp3/4300');
        audio.loop = true;
        audio.volume = 0.5;
        audio.play();
        musicPlaying = true;
    }
}
document.addEventListener("click", playBackgroundMusic);

const heartbeatSound = new Audio('https://www.fesliyanstudios.com/play-mp3/4591');
const jumpSound = new Audio('https://www.fesliyanstudios.com/play-mp3/408');
const doorOpenSound = new Audio('https://www.fesliyanstudios.com/play-mp3/402');

// Play jump sound
document.addEventListener("keydown", (event) => {
    if (event.code === "Space" && !playerState.jumping) {
        jumpSound.play();
    }
});

// Load Textures
const textureLoader = new THREE.TextureLoader();
const floorTexture = textureLoader.load('https://threejs.org/examples/textures/terrain/grasslight-big.jpg');
const wallTexture = textureLoader.load('https://threejs.org/examples/textures/brick_diffuse.jpg');

// Floor
const floorGeometry = new THREE.PlaneGeometry(10, 10);
const floorMaterial = new THREE.MeshStandardMaterial({ map: floorTexture });
const floor = new THREE.Mesh(floorGeometry, floorMaterial);
floor.rotation.x = -Math.PI / 2;
floor.receiveShadow = true;
scene.add(floor);

// Walls
const wallGeometry = new THREE.BoxGeometry(10, 5, 0.5);
const wallMaterial = new THREE.MeshStandardMaterial({ map: wallTexture });

const wall1 = new THREE.Mesh(wallGeometry, wallMaterial);
wall1.position.set(0, 2.5, -5);
wall1.receiveShadow = true;
scene.add(wall1);

const wall2 = new THREE.Mesh(wallGeometry, wallMaterial);
wall2.position.set(0, 2.5, 5);
wall2.receiveShadow = true;
scene.add(wall2);

const sideWallGeometry = new THREE.BoxGeometry(0.5, 5, 10);
const wall3 = new THREE.Mesh(sideWallGeometry, wallMaterial);
wall3.position.set(-5, 2.5, 0);
wall3.receiveShadow = true;
scene.add(wall3);

const wall4 = new THREE.Mesh(sideWallGeometry, wallMaterial);
wall4.position.set(5, 2.5, 0);
wall4.receiveShadow = true;
scene.add(wall4);

// Player (Sphere for smoother look)
const playerGeometry = new THREE.SphereGeometry(0.5, 32, 32);
const playerMaterial = new THREE.MeshStandardMaterial({ color: 0x00ff00 });
const player = new THREE.Mesh(playerGeometry, playerMaterial);
player.position.set(0, 0.5, 0);
scene.add(player);

// Camera Position
camera.position.set(0, 3, 7);
camera.lookAt(player.position);

// Player properties
let playerState = {
    x: 0,
    y: 0.5,
    z: 0,
    velocityY: 0,
    speed: 0.2,
    jumping: false,
    health: 100, 
    hasKey: false
};

// Gravity and Jumping
const gravity = -0.005;
const jumpStrength = 0.15;

// Define wall boundaries
const walls = [
    { x: 0, z: -4.75, width: 10, height: 0.5 },  // Front wall
    { x: 0, z: 4.75, width: 10, height: 0.5 },   // Back wall
    { x: -4.75, z: 0, width: 0.5, height: 10 },  // Left wall
    { x: 4.75, z: 0, width: 0.5, height: 10 }    // Right wall
];

let doorOpen = false;  // Track if the door is open

// Modify wall collision check to allow passing through the open door
function checkWallCollision(newX, newZ) {
    const playerBox = new THREE.Box3().setFromObject(player);

    for (const wall of walls) {
        if (playerBox.intersectsBox(wall.boundingBox)) {
            return true;
        }
    }

    // Allow passage only if the door is removed
    if (!doorOpen && playerBox.intersectsBox(new THREE.Box3().setFromObject(door))) {
        return true;
    }

    return false;
}



// Collision detection with ground
function checkGroundCollision() {
    if (playerState.y <= 0.5) {
        playerState.y = 0.5;
        playerState.velocityY = 0;
        playerState.jumping = false;
    }
}

// Play key pickup sound
function checkKeyCollection() {
    keys.forEach((key, index) => {
        let distance = player.position.distanceTo(key.position);
        if (distance < 1.5 && key.visible) { // If player is close enough
            scene.remove(key); // Remove key from scene
            key.visible = false; // Hide key
            keysCollected++; // Increase collected keys
            score += 10; // Increase score
            updateScore(); // Update scoreboard

            // Play a sound effect
            const audio = new Audio('key-pickup.mp3'); // Add key pickup sound
            audio.play();
        }
    });
}

function checkDoorUnlock() {
    let doorDistance = player.position.distanceTo(door.position);
    if (doorDistance < 2 && keysCollected === totalKeys) {
        door.rotation.y += 0.02; // Open door animation
        document.getElementById("keys").innerText = "Door Unlocked! 🚪";
    }
}

// Update Player Movement
function updatePlayerMovement() {
    let newX = player.position.x;
    let newZ = player.position.z;

    if (moveForward) newZ -= playerState.speed;
    if (moveBackward) newZ += playerState.speed;
    if (moveLeft) newX -= playerState.speed;
    if (moveRight) newX += playerState.speed;

    // Only move if no wall collision
    player.position.set(newX, player.position.y, newZ);

    if (checkWallCollision(newX, newZ)) {
        player.position.set(playerState.x, player.position.y, playerState.z); // Revert to last position
    } else {
        playerState.x = newX;
        playerState.z = newZ;
    }
}


// Update Enemy Movement
function updateEnemy() {
    let dx = player.position.x - enemy.position.x;
    let dz = player.position.z - enemy.position.z;
    let distance = Math.sqrt(dx * dx + dz * dz);

    if (distance > 0.3) {
        let newEnemyX = enemy.position.x + (dx / distance) * enemySpeed;
        let newEnemyZ = enemy.position.z + (dz / distance) * enemySpeed;

        // Prevent enemy from walking through walls
        if (!checkWallCollision(newEnemyX, newEnemyZ)) {
            enemy.position.x = newEnemyX;
            enemy.position.z = newEnemyZ;
        }
    }

}

// Movement Variables
let moveForward = false;
let moveBackward = false;
let moveLeft = false;
let moveRight = false;

// Handle Jumping
document.addEventListener("keydown", (event) => {
    if (event.code === "Space" && !playerState.jumping) {
        playerState.velocityY = jumpStrength;
        playerState.jumping = true;
    }
});

// Key Press Events

window.addEventListener("keydown", (event) => {
    if (event.code === "ArrowUp" || event.code === "KeyW") moveForward = true;
    if (event.code === "ArrowDown" || event.code === "KeyS") moveBackward = true;
    if (event.code === "ArrowLeft" || event.code === "KeyA") moveLeft = true;
    if (event.code === "ArrowRight" || event.code === "KeyD") moveRight = true;
});

window.addEventListener("keyup", (event) => {
    if (event.code === "ArrowUp" || event.code === "KeyW") moveForward = false;
    if (event.code === "ArrowDown" || event.code === "KeyS") moveBackward = false;
    if (event.code === "ArrowLeft" || event.code === "KeyA") moveLeft = false;
    if (event.code === "ArrowRight" || event.code === "KeyD") moveRight = false;
});

// Health Bar
const healthBar = document.createElement("div");
healthBar.style.position = "absolute";
healthBar.style.top = "10px";
healthBar.style.left = "50%";
healthBar.style.transform = "translateX(-50%)";
healthBar.style.width = "200px";
healthBar.style.height = "20px";
healthBar.style.background = "red";
document.body.appendChild(healthBar);

let playerHealth = 100;
let playerSpeed = 0.1;

// Update Health UI
function updateHealth() {
    healthBar.style.width = `${playerState.health}%`;
    if (playerState.health <= 30) heartbeatSound.play();
    if (playerState.health <= 0) {
        alert("Game Over!");
        location.reload();
    }
}

// Enemy AI Logic
const enemyGeometry = new THREE.SphereGeometry(0.5, 32, 32);
const enemyMaterial = new THREE.MeshStandardMaterial({ color: 0xff0000 });
const enemy = new THREE.Mesh(enemyGeometry, enemyMaterial);
enemy.position.set(4, 0.5, 4);
scene.add(enemy);

let enemySpeed = 0.03;
function updateEnemy() {
    let dx = player.position.x - enemy.position.x;
    let dz = player.position.z - enemy.position.z;
    let distance = Math.sqrt(dx * dx + dz * dz);

    if (distance < 0) {
        enemy.position.x += (dx / distance) * enemySpeed;
        enemy.position.z += (dz / distance) * enemySpeed;
        if (distance < 0.06) {
            playerState.health -= 1;
            updateHealth();
        }
    }
}

let score = 0;
let keysCollected = 0;
const totalKeys = 3; // Example: 3 keys to unlock the door

// Function to update the score display
function updateScore() {
    document.getElementById("score").innerText = `Score: ${score}`;
    document.getElementById("keys").innerText = `Keys: ${keysCollected}/${totalKeys}`;
}


// Load Key Texture
function createKey(x, y, z) {
    const keyGeometry = new THREE.TorusKnotGeometry(0.1, 0.03, 100, 16);
    const keyMaterial = new THREE.MeshStandardMaterial({ color: 0xffff00 });
    const key = new THREE.Mesh(keyGeometry, keyMaterial);
    key.position.set(x, y, z);
    key.userData.collectible = true; // Mark as collectible
    scene.add(key);
    return key;
}

// Example: Placing keys in different locations
const keys = [
    createKey(2, 0.5, 2),
    createKey(-3, 0.5, -1),
    createKey(4, 0.5, -3)
];
let hasKey = false;

// Door Object
const doorGeometry = new THREE.BoxGeometry(1.5, 2, 0.2);
const doorMaterial = new THREE.MeshStandardMaterial({ color: 0x654321 });
const door = new THREE.Mesh(doorGeometry, doorMaterial);
door.position.set(0, 1, -4.8);
scene.add(door);
let doorUnlocked = false;

// Collision Detection Function
function checkCollision(object1, object2) {
    const dist = object1.position.distanceTo(object2.position);
    return dist < 0.6;
}

// Display Message Function
function showMessage(message) {
    const messageBox = document.getElementById('gameMessage');
    messageBox.innerText = message;
    messageBox.style.display = 'block';

    setTimeout(() => {
        messageBox.style.display = 'none';
    }, 2000);
}

// Modify Animation Loop
function animate() {
    requestAnimationFrame(animate);

    // Apply Gravity
    playerState.velocityY += gravity;
    playerState.y += playerState.velocityY;
    checkGroundCollision();

    // Player Movement
    if (moveForward) playerState.z -= playerState.speed;
    if (moveBackward) playerState.z += playerState.speed;
    if (moveLeft) playerState.x -= playerState.speed;
    if (moveRight) playerState.x += playerState.speed;

    player.position.set(playerState.x, playerState.y, playerState.z);

    // Check Key and Door Collisions
    checkDoorUnlock();
    checkKeyCollection();

    // Enemy AI
    let dx = player.position.x - enemy.position.x;
    let dz = player.position.z - enemy.position.z;
    let distance = Math.sqrt(dx * dx + dz * dz);

    enemySpeed = distance > 5 ? 0.02 : distance > 2 ? 0.04 : 0.07;
    enemy.position.x += (dx / distance) * enemySpeed;
    enemy.position.z += (dz / distance) * enemySpeed;

    if (distance < 0.06) {
        playerHealth -= 0.5;
        healthBar.style.width = `${playerHealth * 2}px`;
        if (playerHealth <= 0) alert("Game Over!");
    }
    // Camera follows player
    camera.position.lerp(new THREE.Vector3(player.position.x, player.position.y + 2, player.position.z + 5), 0.1);


    renderer.render(scene, camera);
    updateEnemy();
}
animate();

//hand gesture
async function setupWebcam() {
    const video = document.getElementById("webcam");

    try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        video.srcObject = stream;
    } catch (err) {
        console.error("Error accessing webcam:", err);
    }
}

setupWebcam();

async function setupTFBackend() {
    await tf.setBackend("webgl");
    console.log("TensorFlow WebGL Backend Set!");
}

setupTFBackend();

async function loadHandModel() {
    try {
        const model = await handPoseDetection.createDetector(
            handPoseDetection.SupportedModels.MediaPipeHands,
            {
                runtime: "mediapipe",
                modelType: "full",
                solutionPath: "https://cdn.jsdelivr.net/npm/@mediapipe/hands"
            }
        );
        console.log("MediaPipe Hands Model Loaded Successfully!");
        return model;
    } catch (error) {
        console.error("Failed to load MediaPipe Hands Model:", error);
    }
}

loadHandModel();

async function detectHands() {
    const video = document.getElementById("webcam");

    const model = await loadHandModel();
    if (!model) {
        console.error("Hand model is not loaded. Check network and library imports.");
        return;
    }

    setInterval(async () => {
        const hands = await model.estimateHands(video);
        console.log(hands);
    }, 100);
}


function movePlayer(action) {
    switch (action) {
        case "stop":
            player.velocity.set(0, 0, 0);
            break;
        case "jump":
            if (player.onGround) player.velocity.y += 5;
            break;
        case "forward":
            player.velocity.z -= 0.1;
            break;
        case "rotateRight":
            player.rotation.y -= 0.1;
            break;
        case "rotateLeft":
            player.rotation.y += 0.1;
            break;
    }
}
