<?php
session_start();
include 'db.php'; // Ensure this file contains your database connection details

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!isset($_SESSION['username'])) {
        echo json_encode(["success" => false, "message" => "User not logged in"]);
        exit();
    }
    
    $username = $_SESSION['username'];
    $score = intval($_POST['score']);
    
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        die(json_encode(["success" => false, "message" => "Database connection failed"]));
    }
    
    // Get the current high score for the user
    $query = "SELECT MAX(score) as high_score FROM scores WHERE username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $highScore = $row['high_score'] ?? 0;
    
    // Insert new score into the database
    $insertQuery = "INSERT INTO scores (username, score) VALUES (?, ?)";
    $stmt = $conn->prepare($insertQuery);
    $stmt->bind_param("si", $username, $score);
    $stmt->execute();
    
    // Check if the new score is higher than the previous high score
    if ($score > $highScore) {
        $highScore = $score;
    }
    
    echo json_encode(["success" => true, "newScore" => $score, "highScore" => $highScore]);
    $conn->close();
} else {
    echo json_encode(["success" => false, "message" => "Invalid request"]);
}
?>