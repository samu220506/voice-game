
import subprocess
import webbrowser
import time
import os

# Step 1: Open the game in the default web browser
webbrowser.open("file:///mnt/data/airninjas_with_voice/game/index.html")

# Step 2: Wait briefly to let the game load
time.sleep(2)

# Step 3: Launch the voice control script in the background
subprocess.Popen(["python", "game/voice_control.py"], cwd="/mnt/data/airninjas_with_voice")

print("Game launched with voice control!")
